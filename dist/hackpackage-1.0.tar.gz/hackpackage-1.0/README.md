## This is the EDSA hackathon package

It consists of two modules: recursion.py and sorting.py
recursion.py consists of four recursion functions and the sorting.py module contains four sorting algorithms.
